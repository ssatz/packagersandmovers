import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-history-booking',
  templateUrl: './history-booking.component.html',
  styleUrls: ['./history-booking.component.css']
})
export class HistoryBookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
