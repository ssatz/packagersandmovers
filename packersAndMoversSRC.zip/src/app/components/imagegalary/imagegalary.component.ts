import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagegalary',
  templateUrl: './imagegalary.component.html',
  styleUrls: ['./imagegalary.component.css']
})
export class ImagegalaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
