export class Signup {
    userName: string;
    mobile: string;
    address: string;
    status: string;
}