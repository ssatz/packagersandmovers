export class Signup {
    userName: string;
    password: string;
}