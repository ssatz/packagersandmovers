export class Signup {
    name: string;
    mobileNo: string;
    email: string;
    locationFrom: string;
    locationTo: string;
    fromAddress: string;
    toAddress: string;
    receiver: string;
    sender: string;
    goodsType: string;
    pickUpdate: string;
    pickUpTime: string;
}