export class Signup {
    username: string;
    mobile: string;
    landline: string;
    email: string;
    address:String;
    
}